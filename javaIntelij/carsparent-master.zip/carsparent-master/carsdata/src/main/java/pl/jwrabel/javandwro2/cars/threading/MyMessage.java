package pl.jwrabel.javandwro2.cars.threading;

/**
 * Created by jakubwrabel on 18.03.2017.
 */
public class MyMessage {
	String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
}
