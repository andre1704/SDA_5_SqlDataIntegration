package pl.jwrabel.javandwro2.cars.threading;

/**
 * Created by jakubwrabel on 15.03.2017.
 */
public class ThreadingDemo {
	public static void main(String[] args) {


	}
}
