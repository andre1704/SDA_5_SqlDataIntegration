package pl.jwrabel.javandwro2.cars.memory;

import java.util.ArrayList;

/**
 * Created by jakubwrabel on 15.03.2017.
 */
public class VisualVMDemo {
	public static void main(String[] args) throws InterruptedException {
		Thread.sleep(10000);
		Thread.sleep(100000);
	}
}
