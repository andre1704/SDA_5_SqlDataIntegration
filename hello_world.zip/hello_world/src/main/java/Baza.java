import java.util.ArrayList;

/**
 * Created by RENT on 2017-02-11.
 */
public class Baza {
    ArrayList<Film> lista;

    void wypisz() {
        for (Film film : lista)
            film.wypiszDaneFilmu();
    }

    void dodaj(Film film) {
        lista.add(film);
    }

    void usun(Film film) {
        lista.remove(film);
    }
    Baza(ArrayList<Film> lista){
        this.lista=lista;
    }

    public static void main(String[] args) {
        ArrayList<Film> lista = new ArrayList<Film>();
        Film film1 = new Film("Nova", 6);
        Film film2 = new Film("Harry Potter", 6);
        Baza baza = new Baza(lista);
        baza.dodaj(film1);
        baza.dodaj(film2);
        baza.wypisz();
        baza.usun(film1);
        baza.wypisz();
    }
}
