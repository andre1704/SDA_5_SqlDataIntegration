import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * Created by RENT on 2017-02-09.
 */
public class test {
    public static void main(String[] args) {
//        Kwadrat fig1=new Kwadrat(12,"bbb");
//        Kwadrat fig2=new Kwadrat(14,"ccc");
//        Kwadrat fig=new Kwadrat(145,"ggg");
//        ArrayList<Kwadrat> lista = new ArrayList<Kwadrat>();
//        String art1 = "mleko";
//        String art2 = "błuka";
//        String art3 = "banan";
//        lista.add(fig2);
//        lista.add(fig2);
//        lista.add(fig1);
//        fig2.dlugoscBoku=2;
//        for(int i=0; i<lista.size();i++)
//            lista.get(i).opisz();
//
//        for(Kwadrat kw:lista)
//            kw.opisz();
//        String current;
//        System.out.println(lista.size());
//        HashSet<Kwadrat> zbior=new HashSet<Kwadrat>();
//        zbior.add(fig1);
//        zbior.add(fig2);
//        zbior.add(fig2);
//
//        System.out.println(zbior.size());
//        ArrayList<String> lista2=new ArrayList<String>();
//        lista2.add(art1);
//        lista2.add(art2);
//        for(String str:lista2){
//            System.out.println(str);
//        }
//        for(Kwadrat kww: zbior){
//            kww.opisz();
//        }
//        Figura figurka=new Trojkat(23,65656,"orange");
//        ArrayList<Figura> lista3=new ArrayList<Figura>();
//        lista3.add(fig);
//        lista3.add(figurka);
//        for(Figura figure : lista3){
//            figure.figura();
//        }
        ArrayList<Integer> listaIntow = new ArrayList<Integer>();
        ArrayList<Double> listaDouble = new ArrayList<Double>();
        ArrayList<Character> listaChar = new ArrayList<Character>();
        int a = 1;

        listaIntow.add(a);
    }
}
